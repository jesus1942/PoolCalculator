--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AccessoryType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AccessoryType" AS ENUM (
    'CORNER',
    'TRIM',
    'GRILL',
    'BASEBOARD',
    'OTHER',
    'SKIMMER_ITEM',
    'RETURN_ITEM',
    'DRAIN_ITEM'
);


ALTER TYPE public."AccessoryType" OWNER TO postgres;

--
-- Name: AuthProvider; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AuthProvider" AS ENUM (
    'EMAIL',
    'GOOGLE'
);


ALTER TYPE public."AuthProvider" OWNER TO postgres;

--
-- Name: ConstructionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConstructionType" AS ENUM (
    'FIBERGLASS',
    'CONCRETE',
    'BLOCKS',
    'PANELS'
);


ALTER TYPE public."ConstructionType" OWNER TO postgres;

--
-- Name: EquipmentCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EquipmentCategory" AS ENUM (
    'REQUIRED',
    'HEATING',
    'ACCESSORIES',
    'OPTIONAL'
);


ALTER TYPE public."EquipmentCategory" OWNER TO postgres;

--
-- Name: EquipmentType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."EquipmentType" AS ENUM (
    'PUMP',
    'FILTER',
    'HEATER',
    'CHLORINATOR',
    'LIGHTING',
    'OTHER',
    'HEAT_PUMP',
    'TRANSFORMER',
    'SKIMMER',
    'RETURN',
    'HYDRO_JET',
    'VACUUM_INTAKE'
);


ALTER TYPE public."EquipmentType" OWNER TO postgres;

--
-- Name: MaterialType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MaterialType" AS ENUM (
    'CEMENT',
    'WHITE_CEMENT',
    'SAND',
    'STONE',
    'GRAVEL',
    'MARMOLINA',
    'WIRE_MESH',
    'WIRE',
    'NAILS',
    'WATERPROOFING',
    'GEOTEXTILE',
    'OTHER'
);


ALTER TYPE public."MaterialType" OWNER TO postgres;

--
-- Name: PlumbingCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PlumbingCategory" AS ENUM (
    'PIPE',
    'FITTING',
    'VALVE',
    'ACCESSORY'
);


ALTER TYPE public."PlumbingCategory" OWNER TO postgres;

--
-- Name: PlumbingType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PlumbingType" AS ENUM (
    'PVC',
    'FUSION_FUSION',
    'FUSION_ROSCA',
    'POLIPROPILENO',
    'COBRE',
    'OTHER'
);


ALTER TYPE public."PlumbingType" OWNER TO postgres;

--
-- Name: PoolShape; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PoolShape" AS ENUM (
    'RECTANGULAR',
    'CIRCULAR',
    'OVAL',
    'JACUZZI'
);


ALTER TYPE public."PoolShape" OWNER TO postgres;

--
-- Name: ProjectStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProjectStatus" AS ENUM (
    'DRAFT',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'BUDGETED',
    'APPROVED'
);


ALTER TYPE public."ProjectStatus" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'USER',
    'SUPERADMIN',
    'VIEWER'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: TileType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TileType" AS ENUM (
    'COMMON',
    'LOMO_BALLENA',
    'L_FINISH',
    'PERIMETER',
    'OTHER'
);


ALTER TYPE public."TileType" OWNER TO postgres;

--
-- Name: UpdateCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UpdateCategory" AS ENUM (
    'PROGRESS',
    'MILESTONE',
    'ISSUE',
    'NOTE',
    'INSPECTION',
    'DELIVERY',
    'OTHER'
);


ALTER TYPE public."UpdateCategory" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AccessoryPreset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AccessoryPreset" (
    id text NOT NULL,
    name text NOT NULL,
    type public."AccessoryType" NOT NULL,
    unit text NOT NULL,
    "pricePerUnit" double precision NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AccessoryPreset" OWNER TO postgres;

--
-- Name: BusinessRule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BusinessRule" (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    trigger text NOT NULL,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BusinessRule" OWNER TO postgres;

--
-- Name: CalculationSettings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CalculationSettings" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "adhesiveKgPerM2" double precision DEFAULT 5.0 NOT NULL,
    "cementKgPerM3" double precision DEFAULT 200.0 NOT NULL,
    "sandM3PerM3" double precision DEFAULT 0.6 NOT NULL,
    "gravelM3PerM3" double precision DEFAULT 0.8 NOT NULL,
    "groutJointWidthMm" double precision DEFAULT 3.0 NOT NULL,
    "whiteCementKgPerLinealM" double precision DEFAULT 0.15 NOT NULL,
    "marmolinaKgPerLinealM" double precision DEFAULT 0.10 NOT NULL,
    "wireMeshOverlapCm" double precision DEFAULT 10.0 NOT NULL,
    "wireMeshM2PerM2" double precision DEFAULT 1.15 NOT NULL,
    "waterproofingKgPerM2" double precision DEFAULT 0.0 NOT NULL,
    "waterproofingCoats" integer DEFAULT 2 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sidewalkBaseThicknessCm" double precision DEFAULT 10.0 NOT NULL,
    "bedCementBagWeight" double precision DEFAULT 50.0 NOT NULL,
    "bedCementBagsPerM3" double precision DEFAULT 5.0 NOT NULL,
    "bedThicknessCm" double precision DEFAULT 10.0 NOT NULL,
    "drainTrenchDepthCm" double precision DEFAULT 15.0 NOT NULL,
    "drainTrenchWidthCm" double precision DEFAULT 15.0 NOT NULL,
    "electroweldedMeshM2PerM2" double precision DEFAULT 1.15 NOT NULL,
    "geomembraneM2PerM2" double precision DEFAULT 1.0 NOT NULL
);


ALTER TABLE public."CalculationSettings" OWNER TO postgres;

--
-- Name: ConstructionMaterialPreset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConstructionMaterialPreset" (
    id text NOT NULL,
    name text NOT NULL,
    type public."MaterialType" NOT NULL,
    unit text NOT NULL,
    "mixRatio" jsonb,
    "pricePerUnit" double precision NOT NULL,
    brand text,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "bagWeight" double precision
);


ALTER TABLE public."ConstructionMaterialPreset" OWNER TO postgres;

--
-- Name: EquipmentPreset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EquipmentPreset" (
    id text NOT NULL,
    name text NOT NULL,
    type public."EquipmentType" NOT NULL,
    brand text,
    model text,
    power double precision,
    capacity double precision,
    voltage integer,
    "pricePerUnit" double precision NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    category public."EquipmentCategory" DEFAULT 'OPTIONAL'::public."EquipmentCategory" NOT NULL,
    "connectionSize" text,
    consumption double precision,
    "filterArea" double precision,
    "filterDiameter" double precision,
    "flowRate" double precision,
    "isActive" boolean DEFAULT true NOT NULL,
    "maxHead" double precision,
    "maxPoolVolume" double precision,
    "minPoolVolume" double precision,
    "recommendedFilterModel" text,
    "recommendedPumpModel" text,
    "sandRequired" double precision,
    "thermalPower" double precision
);


ALTER TABLE public."EquipmentPreset" OWNER TO postgres;

--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordResetToken" OWNER TO postgres;

--
-- Name: PlumbingItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PlumbingItem" (
    id text NOT NULL,
    name text NOT NULL,
    category public."PlumbingCategory" NOT NULL,
    type public."PlumbingType" NOT NULL,
    diameter text,
    length double precision,
    unit text NOT NULL,
    "pricePerUnit" double precision NOT NULL,
    brand text,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PlumbingItem" OWNER TO postgres;

--
-- Name: PoolPreset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PoolPreset" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "imageUrl" text,
    length double precision NOT NULL,
    width double precision NOT NULL,
    depth double precision NOT NULL,
    "depthEnd" double precision,
    shape public."PoolShape" NOT NULL,
    "hasWetDeck" boolean DEFAULT false NOT NULL,
    "hasStairsOnly" boolean DEFAULT false NOT NULL,
    "returnsCount" integer DEFAULT 2 NOT NULL,
    "hasHotWaterReturn" boolean DEFAULT false NOT NULL,
    "hasBottomDrain" boolean DEFAULT true NOT NULL,
    "hasSkimmer" boolean DEFAULT true NOT NULL,
    "skimmerCount" integer DEFAULT 1 NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "floorCushionDepth" double precision DEFAULT 0.10 NOT NULL,
    "lateralCushionSpace" double precision DEFAULT 0.15 NOT NULL,
    "tileConfig" jsonb,
    "hasHydroJets" boolean DEFAULT false NOT NULL,
    "hasLighting" boolean DEFAULT false NOT NULL,
    "hasVacuumIntake" boolean DEFAULT true NOT NULL,
    "hydroJetsCount" integer DEFAULT 0 NOT NULL,
    "lightingCount" integer DEFAULT 0 NOT NULL,
    "lightingType" text,
    "vacuumIntakeCount" integer DEFAULT 1 NOT NULL,
    "constructionType" public."ConstructionType" DEFAULT 'FIBERGLASS'::public."ConstructionType" NOT NULL,
    "additionalImages" text[] DEFAULT ARRAY[]::text[],
    "backDescription" text
);


ALTER TABLE public."PoolPreset" OWNER TO postgres;

--
-- Name: ProfessionRole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProfessionRole" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "hourlyRate" double precision,
    "dailyRate" double precision,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProfessionRole" OWNER TO postgres;

--
-- Name: Project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Project" (
    id text NOT NULL,
    name text NOT NULL,
    "clientName" text NOT NULL,
    "clientEmail" text,
    "clientPhone" text,
    "poolPresetId" text NOT NULL,
    perimeter double precision NOT NULL,
    "waterMirrorArea" double precision NOT NULL,
    volume double precision NOT NULL,
    "totalTileArea" double precision NOT NULL,
    "sidewalkArea" double precision NOT NULL,
    materials jsonb NOT NULL,
    status public."ProjectStatus" DEFAULT 'DRAFT'::public."ProjectStatus" NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "excavationDepth" double precision NOT NULL,
    "excavationLength" double precision NOT NULL,
    "excavationWidth" double precision NOT NULL,
    "laborCost" double precision DEFAULT 0 NOT NULL,
    location text,
    "materialCost" double precision DEFAULT 0 NOT NULL,
    tasks jsonb NOT NULL,
    "tileCalculation" jsonb NOT NULL,
    "totalCost" double precision DEFAULT 0 NOT NULL,
    "plumbingConfig" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "electricalConfig" jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public."Project" OWNER TO postgres;

--
-- Name: ProjectAdditional; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProjectAdditional" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "accessoryId" text,
    "materialId" text,
    "equipmentId" text,
    "baseQuantity" integer NOT NULL,
    "newQuantity" integer NOT NULL,
    dependencies jsonb NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "customCategory" text,
    "customLaborCost" double precision,
    "customName" text,
    "customPricePerUnit" double precision,
    "customUnit" text,
    "generatedTaskId" text,
    "relatedTaskCategory" text,
    "requiredRoleId" text
);


ALTER TABLE public."ProjectAdditional" OWNER TO postgres;

--
-- Name: ProjectShare; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProjectShare" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "shareToken" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "showCosts" boolean DEFAULT false NOT NULL,
    "showDetails" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "clientPassword" text NOT NULL,
    "clientUsername" text NOT NULL
);


ALTER TABLE public."ProjectShare" OWNER TO postgres;

--
-- Name: ProjectUpdate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProjectUpdate" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    title text NOT NULL,
    description text,
    category public."UpdateCategory" DEFAULT 'PROGRESS'::public."UpdateCategory" NOT NULL,
    images jsonb DEFAULT '[]'::jsonb NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."ProjectUpdate" OWNER TO postgres;

--
-- Name: TilePreset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TilePreset" (
    id text NOT NULL,
    name text NOT NULL,
    width double precision NOT NULL,
    length double precision NOT NULL,
    brand text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    description text,
    "pricePerUnit" double precision NOT NULL,
    type public."TileType" NOT NULL,
    "cornerPricePerUnit" double precision,
    "cornersPerTile" integer,
    "hasCorner" boolean DEFAULT false NOT NULL,
    "isForFirstRing" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."TilePreset" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    password text,
    name text NOT NULL,
    role public."Role" DEFAULT 'USER'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "googleId" text,
    provider public."AuthProvider"
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: AccessoryPreset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AccessoryPreset" (id, name, type, unit, "pricePerUnit", description, "createdAt", "updatedAt") FROM stdin;
f2fbd20f-bb2e-49c7-ac1c-6f6756d0fe3a	Kit Vulcano Completo (Skimmer + 3 Retornos + Virola)	SKIMMER_ITEM	kit	96500	Kit completo marca Vulcano para piscina fibra hasta 12x5m	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
86ac0881-f1c6-4880-8953-5a481405ca0b	Skimmer Vulcano Boca Ancha 20cm	SKIMMER_ITEM	unidad	42000	Skimmer boca ancha de 20cm marca Vulcano	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
2436dfc0-6c0a-4b52-93f4-e8adfd5ea26e	Retorno Orientable Vulcano	RETURN_ITEM	unidad	8500	Retorno orientable de agua marca Vulcano	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
23504c6b-9c7c-4d9c-8d78-1728df86c330	Virola para Limpiafondos	DRAIN_ITEM	unidad	12500	Virola de aspiración para limpiafondos	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
c73a8dd2-c7d2-4abc-950a-075c34fa41c7	Desagüe de Fondo Ø110mm	DRAIN_ITEM	unidad	18500	Desagüe de fondo con rejilla	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
366f5983-c64f-4260-893d-e3d5d5a6dd4d	Remate Lomo Ballena 12x25cm	TRIM	ml	3200	Remate tipo lomo ballena para bordes	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
9db3b986-9b80-4993-b9b2-c1ad2326cbf6	Esquinero Remate	CORNER	unidad	1800	Esquinero para remate de bordes	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
b980c69c-835b-43dd-ba3b-42d2205e2a13	Rejilla Rebosadero	GRILL	ml	4500	Rejilla para canal rebosadero	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
a62d6c92-0218-43f9-af35-80f4fe962c49	Zócalo Cerámico 30cm	BASEBOARD	ml	2100	Zócalo cerámico para terminación	2025-10-26 20:51:44.563	2025-10-26 20:51:44.563
\.


--
-- Data for Name: BusinessRule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BusinessRule" (id, "userId", name, category, trigger, conditions, actions, "isActive", "createdAt", "updatedAt") FROM stdin;
1ec0f2fc-887a-4f89-93b7-4aadf7e58e4e	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	Luz adicional 100W	ELECTRICAL	ADD_LIGHT_100W	{"wattage": 100, "accessoryType": "light"}	[{"name": "Cable 6mm²", "type": "ADD_MATERIAL", "unit": "m", "quantity": 10}, {"type": "CHECK_JUNCTION_BOX", "maxLights": 3}]	t	2025-10-26 17:22:45.793	2025-10-26 17:22:45.793
1eb1b385-4992-4ad3-af02-9eb7e43b7773	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	Luz adicional 300W	ELECTRICAL	ADD_LIGHT_300W	{"wattage": 300, "accessoryType": "light"}	[{"name": "Cable 10mm²", "type": "ADD_MATERIAL", "unit": "m", "quantity": 15}, {"type": "CHECK_JUNCTION_BOX", "maxLights": 3}, {"type": "CHECK_TRANSFORMER", "minWatts": 350}]	t	2025-10-26 17:22:45.806	2025-10-26 17:22:45.806
13818aa2-d298-4c87-89b2-594530db64cb	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	Caja estanco adicional	ELECTRICAL	JUNCTION_BOX_OVERFLOW	{"totalLights": {"gt": 3}}	[{"name": "Caja estanco IP68", "type": "ADD_ACCESSORY", "quantity": 1}]	t	2025-10-26 17:22:45.809	2025-10-26 17:22:45.809
14ce50ce-5526-4577-afad-d1851b23a81c	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	Hidrojet adicional	HYDRAULIC	ADD_HYDROJET	{"accessoryType": "hydrojet"}	[{"name": "Caño PVC 1.5\\"", "type": "ADD_MATERIAL", "unit": "m", "quantity": 3}, {"name": "Codo 45° 1.5\\"", "type": "ADD_MATERIAL", "unit": "u", "quantity": 2}, {"name": "Válvula esférica 1.5\\"", "type": "ADD_MATERIAL", "unit": "u", "quantity": 1}, {"type": "CHECK_PUMP_CAPACITY", "additionalGPM": 15}]	t	2025-10-26 17:22:45.811	2025-10-26 17:22:45.811
fc937556-ffd0-4562-88f2-85302aea43ed	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	Retorno adicional	HYDRAULIC	ADD_RETURN	{"accessoryType": "return"}	[{"name": "Caño PVC 1.5\\"", "type": "ADD_MATERIAL", "unit": "m", "quantity": 2}, {"name": "Codo barrido 1.5\\"", "type": "ADD_MATERIAL", "unit": "u", "quantity": 1}, {"name": "Fitting retorno", "type": "ADD_MATERIAL", "unit": "u", "quantity": 1}, {"type": "CHECK_PUMP_CAPACITY", "additionalGPM": 10}]	t	2025-10-26 17:22:45.814	2025-10-26 17:22:45.814
ea509204-b7fb-4107-bfd9-0c9cd597d4d1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	Skimmer adicional	HYDRAULIC	ADD_SKIMMER	{"accessoryType": "skimmer"}	[{"name": "Caño PVC 2\\"", "type": "ADD_MATERIAL", "unit": "m", "quantity": 4}, {"name": "Codo barrido 2\\"", "type": "ADD_MATERIAL", "unit": "u", "quantity": 2}, {"name": "Canasta skimmer", "type": "ADD_MATERIAL", "unit": "u", "quantity": 1}, {"name": "Tapa skimmer", "type": "ADD_MATERIAL", "unit": "u", "quantity": 1}, {"type": "CHECK_PUMP_CAPACITY", "additionalGPM": 35}]	t	2025-10-26 17:22:45.816	2025-10-26 17:22:45.816
751db1bb-7e26-43ce-a0ca-6cacf41336ab	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	Upgrade bomba por hidrojets	PUMP	PUMP_UPGRADE_HYDROJETS	{"totalHydrojets": {"gte": 2}}	[{"type": "SUGGEST_PUMP_UPGRADE", "percentIncrease": 25}]	t	2025-10-26 17:22:45.819	2025-10-26 17:22:45.819
\.


--
-- Data for Name: CalculationSettings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CalculationSettings" (id, "userId", "adhesiveKgPerM2", "cementKgPerM3", "sandM3PerM3", "gravelM3PerM3", "groutJointWidthMm", "whiteCementKgPerLinealM", "marmolinaKgPerLinealM", "wireMeshOverlapCm", "wireMeshM2PerM2", "waterproofingKgPerM2", "waterproofingCoats", "createdAt", "updatedAt", "sidewalkBaseThicknessCm", "bedCementBagWeight", "bedCementBagsPerM3", "bedThicknessCm", "drainTrenchDepthCm", "drainTrenchWidthCm", "electroweldedMeshM2PerM2", "geomembraneM2PerM2") FROM stdin;
508adacb-d6d0-4ba5-a696-21bda3604ff8	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	5	200	0.6	0.8	3	0.15	0.1	10	1.15	0	2	2025-10-26 16:04:03.96	2025-10-26 16:04:03.96	10	50	5	10	15	15	1.15	1
a9922840-b142-48e8-958f-f4a9f59fda9f	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	5	200	0.6	0.8	3	0.15	0.1	10	1.15	2	2	2025-10-04 22:14:36.828	2025-10-04 22:14:36.828	10	50	5	10	15	15	1.15	1
\.


--
-- Data for Name: ConstructionMaterialPreset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConstructionMaterialPreset" (id, name, type, unit, "mixRatio", "pricePerUnit", brand, description, "createdAt", "updatedAt", "bagWeight") FROM stdin;
0311b989-5678-48ba-aa19-45ad990bab42	Cemento Portland Loma Negra CPC40	CEMENT	bolsa 50kg	\N	12500	Loma Negra	Cemento Portland Compuesto, ideal para hormigones y morteros	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	50
e2ac1981-6bb8-44f6-a7d9-91b3740fa991	Cemento Blanco Minetti x 25kg	WHITE_CEMENT	bolsa 25kg	\N	18500	Minetti	Cemento blanco para pastina y terminaciones	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	25
a21e8a6c-ace8-48cd-b422-520836d3de06	Arena Gruesa	SAND	m³	\N	45000	\N	Arena cernida gruesa para hormigón y cama de apoyo	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
ff90d333-763d-4074-a7d2-0611898222c3	Arena Fina Lavada	SAND	m³	\N	52000	\N	Arena fina lavada para mezclas finas y revoque	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
e3ca048c-b989-4cfb-9b4c-e29ab1b514c7	Canto Rodado 6-20mm	STONE	m³	\N	62000	\N	Piedra canto rodado para hormigón H17-H21	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
bf17291f-c163-4d88-8f55-0dbb2ec28562	Piedra Partida Granza	GRAVEL	m³	\N	58000	\N	Piedra partida 6-12mm para hormigón	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
3472e406-d695-43ed-83e3-55002c5b4296	Piedra para Drenaje	GRAVEL	m³	\N	35000	\N	Piedra gruesa para zanjas de drenaje	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
82033027-f768-4ac3-bdb0-9c67f7b99c1e	Marmolina Blanca x 30kg	MARMOLINA	bolsa	\N	8500	\N	Marmolina blanca para pastina de losetas	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	30
15949210-fd0f-48f0-971d-cbe018fdabdf	Malla de Acero Q188 6x2.15m	WIRE_MESH	m²	\N	4200	\N	Malla electrosoldada Q188 para vereda	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
c4a6efa0-3f0e-4a6b-8ae4-2bf32791ef74	Malla Electrosoldada Q335	WIRE_MESH	m²	\N	6800	\N	Malla reforzada para cama y estructuras	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
934078de-1705-4557-ac09-d81d0a0d679c	Impermeabilizante Sika 1 x 20kg	WATERPROOFING	kg	\N	2800	Sika	Impermeabilizante en polvo para morteros	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
759ab1d2-418d-499e-bfeb-15adf5242129	Membrana Geotextil 200 Micrones	GEOTEXTILE	m²	\N	1200	\N	Geomembrana para base de piscina	2025-10-26 20:51:44.555	2025-10-26 20:51:44.555	\N
\.


--
-- Data for Name: EquipmentPreset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EquipmentPreset" (id, name, type, brand, model, power, capacity, voltage, "pricePerUnit", description, "createdAt", "updatedAt", category, "connectionSize", consumption, "filterArea", "filterDiameter", "flowRate", "isActive", "maxHead", "maxPoolVolume", "minPoolVolume", "recommendedFilterModel", "recommendedPumpModel", "sandRequired", "thermalPower") FROM stdin;
354ce170-989d-4b09-b17a-7a75b52172f5	Bomba Astralpool Sena 0.5 HP	PUMP	AstralPool	Sena 0.5	0.5	8	220	185000	Bomba autocebante 8 m³/h, monofásica	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
742db9f2-5b38-4d0c-b837-99e490ccd689	Bomba Astralpool Sena 0.75 HP	PUMP	AstralPool	Sena 0.75	0.75	12	220	225000	Bomba autocebante 12 m³/h, monofásica	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
b3ca4a7a-a9da-41f2-969b-f6a8e74d3993	Bomba Astralpool Sena 1 HP	PUMP	AstralPool	Sena 1	1	15	220	285000	Bomba autocebante 15 m³/h, monofásica	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
083f6d29-2211-4a26-9266-0e4fd6ebcf17	Bomba Peabody 1 HP Autocebante	PUMP	Peabody	PB-POOL100	1	14	220	195000	Bomba para piscina autocebante	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
81943abf-e0de-4fa4-8863-f2de82813315	Filtro Astralpool Aster Ø400 7m³/h	FILTER	AstralPool	Aster 400	\N	7	\N	165000	Filtro de arena con válvula multipuerta 6 vías	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
daec3208-c0db-4031-ba1c-3461b0fc7fba	Filtro Astralpool Aster Ø500 10m³/h	FILTER	AstralPool	Aster 500	\N	10	\N	225000	Filtro de arena con válvula multipuerta 6 vías	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
31052cec-07b1-4ad4-ad74-5702e0dcd2c8	Filtro Astralpool Aster Ø600 14m³/h	FILTER	AstralPool	Aster 600	\N	14	\N	295000	Filtro de arena con válvula multipuerta 6 vías	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
fa00ad5d-4f4a-4eae-8971-76770a35a460	Arena Sílice para Filtro x 25kg	FILTER	Genérica	\N	\N	\N	\N	8500	Arena sílice granulometría 0.5-1mm	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
a5082ca9-255a-447e-85ca-009220271f2a	Calefactor Solar 30.000 Kcal	HEATER	Genérico	\N	\N	30	\N	285000	Colector solar para piscinas hasta 40m³	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
6c5cd606-4f46-499b-9b30-46c5738eb84c	Intercambiador de Calor 40.000 Kcal	HEATER	Astralpool	\N	\N	40	\N	425000	Intercambiador de calor de titanio	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
f4b1e8d3-5d96-4feb-85fe-436e58a28bb3	Clorador Salino Astralpool 35g/h	CHLORINATOR	AstralPool	Next Salt	\N	35	\N	485000	Clorador salino para piscinas hasta 60m³	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
e04f1bf8-875e-43a2-88af-42cfb8711906	Clorador Salino Astralpool 60g/h	CHLORINATOR	AstralPool	Next Salt Pro	\N	60	\N	685000	Clorador salino para piscinas hasta 100m³	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
d6db5464-9ac4-4c2f-bd6e-f1bb6c06f314	Dosificador Cloro Flotante	CHLORINATOR	Genérico	\N	\N	\N	\N	8500	Dosificador flotante para pastillas de cloro	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
456ce867-9050-4cb7-b032-7fec3b3b1927	Luz LED RGB 18W 12V IP68	LIGHTING	Genérica	\N	18	\N	12	32000	Luz LED RGB sumergible con control remoto	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
fe6ebdf3-ec8c-410b-9d85-8a0fa3993d73	Luz LED Blanca 35W 12V	LIGHTING	Genérica	\N	35	\N	12	28000	Luz LED blanca sumergible	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
8e61e156-dc8a-48b1-b9a8-7516f81e8e3b	Transformador 220V a 12V 300W	LIGHTING	Genérico	\N	300	\N	220	42000	Transformador para luces LED 12V	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
c3d0a375-f653-4bc9-bfde-4836ebb06c9b	Timer Digital Programable	OTHER	Genérico	\N	\N	\N	\N	18500	Timer digital para programación de bomba	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
7040c003-ab04-4eb8-9c1f-3def32634568	Regulador de Nivel Automático	OTHER	Astralpool	\N	\N	\N	\N	52000	Sistema automático de llenado	2025-10-26 20:51:44.567	2025-10-26 20:51:44.567	OPTIONAL	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordResetToken" (id, "userId", token, "expiresAt", used, "createdAt") FROM stdin;
4b526a0f-192c-4bb7-a1c5-d453b7964dfa	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	4104b5a55e4139c897e9f9c6930c7bc2d8489dc0c3b3f6bdc22167144926eff4	2025-10-26 16:13:16.91	f	2025-10-26 15:13:16.913
\.


--
-- Data for Name: PlumbingItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PlumbingItem" (id, name, category, type, diameter, length, unit, "pricePerUnit", brand, description, "createdAt", "updatedAt") FROM stdin;
212047d6-d440-49a9-bc3b-d1d51e2534f3	Caño PVC 63mm x 4m Awaduct	PIPE	PVC	63mm	4	unidad	12500	Awaduct	Caño PVC presión clase 10 para red principal	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
6ea002c4-6125-4400-80bb-f86ae0e90ae0	Caño PVC 50mm x 4m Awaduct	PIPE	PVC	50mm	4	unidad	9800	Awaduct	Caño PVC presión clase 10	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
d95df003-c587-456d-8bc3-a66b58b83dea	Caño PVC 40mm x 4m Awaduct	PIPE	PVC	40mm	4	unidad	7200	Awaduct	Caño PVC presión para retornos y accesorios	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
838961a1-e356-4a99-959f-0b75b2fc7c79	Caño PVC 32mm x 4m	PIPE	PVC	32mm	4	unidad	5600	\N	Caño PVC para conexiones secundarias	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
b32d44aa-7299-4521-a782-fc6bc8794fe6	Caño Fusión 63mm x 6m Tigre	PIPE	FUSION_FUSION	63mm	6	unidad	18500	Tigre	Caño termofusión PPR para agua caliente/fría	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
2f10d786-731d-454b-8b50-c0ee79b10934	Caño Fusión 50mm x 6m Tigre	PIPE	FUSION_FUSION	50mm	6	unidad	14200	Tigre	Caño termofusión PPR	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
2676a8c1-cdea-49ff-a59a-1f9b0179b1f0	Codo PVC 90° 63mm	FITTING	PVC	63mm	\N	unidad	3200	\N	Codo 90 grados a presión	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
5d1d605c-2629-4d60-8429-a269d7ff4408	Codo PVC 90° 50mm	FITTING	PVC	50mm	\N	unidad	2100	\N	Codo 90 grados a presión	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
d799da80-1995-4798-809a-96977b2a337e	Codo PVC 90° 40mm	FITTING	PVC	40mm	\N	unidad	1600	\N	Codo 90 grados a presión	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
d9401aac-39b5-4a77-b1d8-3bde8d2ff5e9	Te PVC 63mm	FITTING	PVC	63mm	\N	unidad	4200	\N	Te derivación 90 grados	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
291310c1-a3a2-4219-8eac-62d076e0feb9	Te PVC 50mm	FITTING	PVC	50mm	\N	unidad	2800	\N	Te derivación 90 grados	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
d959ca91-07bf-4aaf-8f68-46c3c0bdf401	Válvula Esférica PVC 63mm	VALVE	PVC	63mm	\N	unidad	8900	\N	Válvula de corte esférica presión	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
28842334-a7ed-4cfa-a7e5-cfbaabe3023b	Válvula Esférica PVC 50mm	VALVE	PVC	50mm	\N	unidad	6500	\N	Válvula de corte esférica presión	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
c7774d82-da9d-4a4d-b7e6-21cf62166304	Válvula Check 50mm	VALVE	PVC	50mm	\N	unidad	7200	\N	Válvula anti-retorno	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
66e264ae-8eb3-45c6-8adc-3159acdb298e	Pegamento PVC x 250ml Awaduct	ACCESSORY	OTHER	\N	\N	unidad	3500	Awaduct	Pegamento para PVC presión	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
8761c978-d92d-45d8-986b-ebc848bc478e	Teflón para Roscas x 12mm	ACCESSORY	OTHER	\N	\N	rollo	800	\N	Cinta teflón para sellado de roscas	2025-10-26 20:51:44.56	2025-10-26 20:51:44.56
\.


--
-- Data for Name: PoolPreset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PoolPreset" (id, name, description, "imageUrl", length, width, depth, "depthEnd", shape, "hasWetDeck", "hasStairsOnly", "returnsCount", "hasHotWaterReturn", "hasBottomDrain", "hasSkimmer", "skimmerCount", "userId", "createdAt", "updatedAt", "floorCushionDepth", "lateralCushionSpace", "tileConfig", "hasHydroJets", "hasLighting", "hasVacuumIntake", "hydroJetsCount", "lightingCount", "lightingType", "vacuumIntakeCount", "constructionType", "additionalImages", "backDescription") FROM stdin;
910f846d-9145-4271-9681-955f802a9f41	Topacio	Modelo de la línea ACQUAM classic. Piscina con estilo, ideal para espacios reducidos. Profundidad uniforme 0.90m.	/pool-images/acquam-page-04.png	3.35	2	0.9	\N	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.781	2025-10-26 17:32:38.854	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
7f8ecfb6-f0af-4405-897f-9dc18a93e503	Cuarzo	Modelo de la línea ACQUAM classic. Piscina de formato rectangular, óptima para espacios reducidos. Profundidad uniforme 1.05m.	/pool-images/acquam-page-05.png	4.1	2.3	1.05	\N	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.789	2025-10-26 17:32:38.86	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
bd4e0c7e-3c56-4d19-a154-2eb6a0791a36	Tanzanita	Modelo de la línea ACQUAM classic. Diseño sobrio y robusto. La más resistente del mercado por su forma curva. Profundidad uniforme 1.10m.	/pool-images/acquam-page-06.png	4.55	2.55	1.1	\N	OVAL	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.794	2025-10-26 17:32:38.866	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
bdb70324-67f8-49c3-993f-a013489291ad	Circón	Modelo de la línea ACQUAM classic. Diseño rectangular que incorpora Playa Húmeda y escalinata. Profundidad de 1.30 a 1.40m.	/pool-images/acquam-page-08.png	5.5	2.8	1.3	1.4	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.805	2025-10-26 17:32:38.878	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
a99d5e57-c625-4daa-b4bb-345ecd6a8790	Ambar	Modelo de la línea ACQUAM classic. Destaca su estética con escaleras dentro del arco romano, con espacio libre para nadar. Profundidad de 1.25 a 1.50m.	/pool-images/acquam-page-09.png	5.6	2.8	1.25	1.5	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.81	2025-10-26 17:32:38.883	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
63dd98c5-cb95-4e65-988b-7e143a9c29d5	Amatista	Modelo de la línea ACQUAM classic. Diseño que se destaca por su estilo definido cuenta con escaleras dentro del arco romano. Profundidad de 1.45 a 1.60m.	/pool-images/acquam-page-10.png	6.5	3.1	1.45	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.816	2025-10-26 17:32:38.887	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
cdf387f8-cb41-4531-8939-f3a9913379b7	Turquesa	Modelo de la línea ACQUAM classic. Diseño elegante que incorpora escaleras en todo el ancho de la piscina. Amplitud para disfrutar. Profundidad de 1.30 a 1.60m.	/pool-images/acquam-page-11.png	6.5	3.1	1.3	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.821	2025-10-26 17:32:38.892	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
5229a74d-b89a-403a-880b-999508fe52d0	Turmalina	Modelo de la línea ACQUAM classic. Diseño práctico que incorpora Playa Húmeda y escalinata para tomar sol. Profundidad de 1.40 a 1.60m.	/pool-images/acquam-page-12.png	7.3	3.5	1.4	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.826	2025-10-26 17:32:38.898	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
5436c004-641d-44ec-803a-53ede6589393	Gema Azul	Modelo de la línea ACQUAM classic. Diseño cómodo y funcional. Es todo lo que necesitás para disfrutar de tu piscina en casa. Profundidad de 1.40 a 1.60m.	/pool-images/acquam-page-13.png	7.3	3.55	1.4	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.831	2025-10-26 17:32:38.908	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
cbd216c3-fb6b-4deb-854b-c3de55287645	Ópalo	Modelo de la línea ACQUAM classic. Con arco romano, Playa Húmeda y escaleras que invitan a un relax. Todo el confort en una sola Piscina. Profundidad de 1.40 a 1.55m.	/pool-images/acquam-page-14.png	7.3	3.4	1.4	1.55	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.836	2025-10-26 17:32:38.915	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
bedf76cc-ef4c-4c0e-bbe0-40c011d40c44	Agua Marina	Modelo de la línea ACQUAM classic. Diseño clásico y distinguido con arco romano. Escaleras independientes del área de nado. Profundidad de 1.45 a 1.60m.	/pool-images/acquam-page-15.png	7.3	3.5	1.45	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.841	2025-10-26 17:32:38.922	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
e18ba7f6-6303-4c82-829d-f53418b29d59	Ágata	Modelo de la línea ACQUAM classic. Piscina de diseño ovalado en ambos extremos, una de las más robustas del mercado. Profundidad de 1.40 a 1.60m.	/pool-images/acquam-page-16.png	7.4	3.5	1.4	1.6	OVAL	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.846	2025-10-26 17:32:38.927	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
c9b4411d-e6c0-4433-9d5d-c24c2db555e6	Onix	Modelo de la línea ACQUAM classic. Diseño con estilo propio. Escaleras que abarcan todo el ancho de la piscina con un escalón más amplio para tomar sol. Profundidad de 1.45 a 1.60m.	/pool-images/acquam-page-18.png	8	4	1.45	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.862	2025-10-26 17:32:38.936	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
250012c8-adaa-489b-bfbb-62a1a090e61c	Zafiro	Modelo de la línea ACQUAM classic. Bellísima piscina con escaleras dentro del arco romano, especial para embellecer un jardín tradicional. Profundidad de 1.50 a 1.60m.	/pool-images/acquam-page-19.png	8.4	4	1.5	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.87	2025-10-26 17:32:38.943	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
28674649-5df9-4f10-8340-382370813c59	Espinela	Modelo de la línea ACQUAM classic. Para vivir tu verano en libertad disfrutando de sus amplias escalinatas que invitan a compartir un refrescante baño. Profundidad de 1.40 a 1.50m.	/pool-images/acquam-page-20.png	9	3.75	1.4	1.5	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.875	2025-10-26 17:32:38.95	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
6a0ca510-f709-4a99-9d42-8bdb4d4b3f34	Aventurina	Modelo de la línea ACQUAM classic. Una Piscina con todo lo que necesitás para vivir un verano feliz. Playa húmeda, escalinatas, caja de nado amplísima. Profundidad de 1.40 a 1.60m.	/pool-images/acquam-page-21.png	9	4	1.4	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.88	2025-10-26 17:32:38.958	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
577a728f-f13d-4aeb-9345-124635088119	Coral		/pool-images/acquam-page-26.png	7	3.5	1.4	0	RECTANGULAR	t	t	4	f	t	t	1	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-04 14:18:04.873	2025-10-26 17:32:38.979	0.1	0.15	\N	f	t	t	0	1	Led RGBA	1	FIBERGLASS	{}	\N
ac14e499-bc29-4335-9ca0-9afb68556ee1	Jacuzzi	Jacuzzi circular con 11 jets regulables, 1 bomba aireadora y 1 bomba de 3/4. Capacidad para 4-6 personas.	/pool-images/acquam-page-03.png	1.9	1.9	0.8	\N	CIRCULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.764	2025-10-26 17:32:38.847	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
459035cb-ccfb-498d-8e57-21e19b10ce29	Jaspe	Modelo de la línea ACQUAM classic. Diseño compacto y delicado, de composición resistente por su forma curva. Profundidad uniforme 1.30m.	/pool-images/acquam-page-07.png	5.45	3	1.3	\N	OVAL	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.799	2025-10-26 17:32:38.872	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
9fbbbc25-2b42-4d86-925e-2b6590704ef4	Zafiro Azul	Modelo de la línea ACQUAM classic. Diseño y funcionalidad con Playa Húmeda y escalinata. Viví el verano disfrutando del sol y el agua. Profundidad de 1.40 a 1.50m.	/pool-images/acquam-page-17.png	8	3.6	1.4	1.5	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.855	2025-10-26 17:32:38.931	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
c68b5038-9304-45af-a17c-bab3da57d55d	Alejandrita	Modelo de la línea ACQUAM classic. Confort y lujo para tu verano. Extensa Playa Húmeda y dos escalones en una esquina. El modelo ideal para invitar a divertirse. Profundidad de 1.40 a 1.60m.	/pool-images/acquam-page-22.png	10	4	1.4	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.885	2025-10-26 17:32:38.964	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
90eed97b-9b1f-41a6-ba88-47659bc38055	Diamante Rojo	Modelo de la línea ACQUAM classic. Un diamante rojo no solo es atemporal y elegante, sino que es una pieza destacada para cualquier joyero. Esta piscina es la más amplia. Profundidad de 1.40 a 1.60m.	/pool-images/acquam-page-23.png	10	4.9	1.4	1.6	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.894	2025-10-26 17:32:38.969	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
3b7929ed-1dc5-445a-8b64-5fc6522a3cbb	Kriptonita	Modelo de la línea ACQUAM compact. Cuenta con doble Playa Húmeda. Ideal para descansar en familia disfrutando el calor y el confort. Profundidad uniforme 1.30m.	/pool-images/acquam-page-25.png	6	2.9	1.3	\N	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.9	2025-10-26 17:32:38.974	0.1	0.15	\N	f	f	t	0	0	\N	1	FIBERGLASS	{}	\N
8a58ecff-d826-4cd2-bde5-0da20bed9344	Jade	Modelo de la línea ACQUAM compact. Tamaño especial para nadar y disfrutar del sol con amigos haciendo uso de su doble Playa Húmeda. Adelantate al verano. Profundidad de 1.40 a 1.45m.	/pool-images/acquam-page-27.png	8	3.3	1.4	1.45	RECTANGULAR	f	f	2	f	t	t	1	e84513b2-620b-46cb-86c6-cadd1f4bc5b9	2025-10-26 17:32:17.91	2025-10-26 20:25:00.446	0.1	0.15	\N	f	f	t	0	0		1	FIBERGLASS	{}	
60dcc637-bcad-4715-bf1f-7fdaa4a476d3	Citrino	Espectacular diseño compacto para espacios reducidos.	/uploads/pool-1761504884961-985727230.png	5	2.5	1.3	0	RECTANGULAR	t	f	4	t	t	t	1	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:54:45.001	2025-10-26 18:54:45.001	0.1	0.15	\N	f	t	t	0	2	Led	1	FIBERGLASS	{/uploads/pool-1761504884995-377116998.png}	Descripcion a fondo de las medidas de esta espectacular piscina.
\.


--
-- Data for Name: ProfessionRole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProfessionRole" (id, name, description, "hourlyRate", "dailyRate", "userId", "createdAt", "updatedAt") FROM stdin;
6a447596-6669-4361-a8b0-7a1bbf6a8155	Albañil	Construcción de estructura y mampostería	\N	\N	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-05 01:48:39.753	2025-10-05 01:48:39.753
7c7284d4-964c-4f9a-b3af-1b9ceb70dd5a	Colocador de Losetas	Instalación de revestimientos	\N	\N	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-05 01:48:39.753	2025-10-05 01:48:39.753
67e25537-b2ea-4070-8a0f-b862fce889e9	Pintor	Pintura y acabados	\N	\N	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-05 01:48:39.753	2025-10-05 01:48:39.753
3e44122b-4ca7-462d-b68a-fb05c61b39e7	Gasista	Instalación de gas para calefacción	\N	\N	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-05 01:48:39.753	2025-10-05 01:48:39.753
bcaf8de7-8fd6-4fa5-98a2-04f90d3331ba	Electricista	Instalación eléctrica y iluminación	\N	90000	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-05 01:48:39.753	2025-10-05 01:49:21.948
cf73f44a-d94e-40da-a60f-572c7c1235dc	Excavador	Movimiento de suelos y excavación	\N	45000	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-05 01:48:39.753	2025-10-05 03:56:28.209
18e26116-9ab1-40ac-b235-bea8bb9f9b91	Sanitarista	Instalación de cañerías y sistemas de agua	\N	80000	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-05 01:48:39.753	2025-10-05 03:56:57.007
9fb2bae6-c6db-43fc-99a1-1ac4cb3d910b	Instalador de Equipos	Instalación de bombas y filtros	\N	85000	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-05 01:48:39.753	2025-10-05 03:57:07.027
7bcd07be-7414-42e9-a30e-2c2a71053748	Albañil	Construcción de estructura y mampostería	\N	\N	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:19.548	2025-10-26 18:56:19.548
2261d2e1-a610-4bf2-a890-5e068fe9253e	Sanitarista	Instalación de cañerías y sistemas de agua	\N	\N	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:19.548	2025-10-26 18:56:19.548
cae7aa33-e9cb-4804-9e56-35a981492ffb	Electricista	Instalación eléctrica y iluminación	\N	\N	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:19.548	2025-10-26 18:56:19.548
1b6acecc-1a86-4535-a399-adde5211576c	Colocador de Losetas	Instalación de revestimientos	\N	\N	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:19.548	2025-10-26 18:56:19.548
1c9d3dcc-ef38-47ab-91cd-c795e3c2656c	Excavador	Movimiento de suelos y excavación	\N	\N	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:19.548	2025-10-26 18:56:19.548
4c1404f4-3540-40df-aa08-4ba251437401	Instalador de Equipos	Instalación de bombas y filtros	\N	\N	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:19.548	2025-10-26 18:56:19.548
397cdafd-c579-49c2-8db6-3a7f28a0b1f8	Pintor	Pintura y acabados	\N	\N	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:19.548	2025-10-26 18:56:19.548
76a4f599-68f0-44ac-bdca-505b8fc0fe1f	Gasista	Instalación de gas para calefacción	\N	\N	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:19.548	2025-10-26 18:56:19.548
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Project" (id, name, "clientName", "clientEmail", "clientPhone", "poolPresetId", perimeter, "waterMirrorArea", volume, "totalTileArea", "sidewalkArea", materials, status, "userId", "createdAt", "updatedAt", "excavationDepth", "excavationLength", "excavationWidth", "laborCost", location, "materialCost", tasks, "tileCalculation", "totalCost", "plumbingConfig", "electricalConfig") FROM stdin;
c5bcf8aa-2f46-4da7-9e93-e5b526f78221	Familia Cayo	Jorge Cayo	\N	\N	577a728f-f13d-4aeb-9345-124635088119	21	24.5	34.3	24.5	24.5	{"sand": {"unit": "m³", "quantity": "1.47"}, "cement": {"unit": "kg", "quantity": 491}, "gravel": {"unit": "m³", "quantity": "1.96"}, "adhesive": {"unit": "kg", "quantity": 123}, "cementKg": {"unit": "kg", "quantity": 613}, "wireMesh": {"unit": "m²", "quantity": 29}, "marmolina": {"unit": "kg", "quantity": 12}, "cementBags": {"unit": "bolsas de 50kg", "quantity": 13}, "drainStone": {"unit": "m³", "quantity": "0.00"}, "sandForBed": {"unit": "m³", "quantity": "2.45"}, "geomembrane": {"unit": "m²", "quantity": 25}, "whiteCement": {"unit": "kg", "quantity": 18}, "waterproofing": {"unit": "kg", "quantity": 98}, "electroweldedMesh": {"unit": "m²", "quantity": 29}}	IN_PROGRESS	49ffe98c-d5a0-45f6-9eba-0027c2398ad7	2025-10-04 14:19:29.344	2025-10-06 11:58:30.917	1.5	7.3	3.8	0	Llao Llao casi los Paraísos	0	{}	{"east": {"rows": 4, "firstRingType": "LOMO_BALLENA", "selectedTileId": "3082817c-c45a-44c6-8dc0-7c7e413eaee5"}, "west": {"rows": 2, "firstRingType": "LOMO_BALLENA", "selectedTileId": "3082817c-c45a-44c6-8dc0-7c7e413eaee5"}, "north": {"rows": 2, "firstRingType": "LOMO_BALLENA", "selectedTileId": "3082817c-c45a-44c6-8dc0-7c7e413eaee5"}, "south": {"rows": 2, "firstRingType": "LOMO_BALLENA", "selectedTileId": "3082817c-c45a-44c6-8dc0-7c7e413eaee5"}}	0	{"selectedItems": [{"itemId": "6ee449da-db02-4746-93a9-cd98f16b58d2", "category": "FITTING", "diameter": "40mm", "itemName": "Codo 90º", "quantity": 50, "pricePerUnit": 15000}, {"itemId": "1ac54ef6-1be5-4865-b0f7-cb234c554279", "category": "PIPE", "diameter": "40mm", "itemName": "Caño gris tigre PN10 ", "quantity": 14, "pricePerUnit": 47000}], "distanceToEquipment": 5}	{}
3c1ee805-e1c3-4e19-9e66-d1eb8c1dbb1f	Familia Figueroa	Luis Figueroa	\N	\N	60dcc637-bcad-4715-bf1f-7fdaa4a476d3	15	12.5	16.25	0	0	{"sand": {"cost": 0, "unit": "m³", "quantity": "0.00"}, "tiles": [], "cement": {"cost": 0, "unit": "kg", "quantity": 0}, "gravel": {"cost": 0, "unit": "m³", "quantity": "0.00"}, "adhesive": {"cost": 0, "unit": "kg", "quantity": 0}, "cementKg": {"cost": 3912500, "unit": "kg", "quantity": 313}, "wireMesh": {"cost": 0, "unit": "m²", "quantity": 0}, "marmolina": {"cost": 76500, "unit": "kg", "quantity": 9}, "cementBags": {"cost": 0, "unit": "bolsas de 50kg", "quantity": 7}, "drainStone": {"cost": 0, "unit": "m³", "quantity": "0.00"}, "sandForBed": {"cost": 56250, "unit": "m³", "quantity": "1.25"}, "geomembrane": {"cost": 0, "unit": "m²", "quantity": 13}, "whiteCement": {"cost": 240500, "unit": "kg", "quantity": 13}, "waterproofing": {"cost": 0, "unit": "kg", "quantity": 0}, "electroweldedMesh": {"cost": 0, "unit": "m²", "quantity": 15}}	IN_PROGRESS	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 18:56:16.666	2025-10-26 18:56:48.074	1.4	5.3	2.8	0	\N	4285750	{"floor": [{"id": "b39572b6-e6e2-4c67-a48b-9ca937de7c3b", "name": "Colocación de geomembrana", "status": "pending", "category": "floor", "laborCost": 0, "description": "Instalación de geomembrana en 12.50m²", "estimatedHours": 3, "suggestedRoleType": "Albañil"}, {"id": "a05a84be-5d21-48fd-900d-cb20d50e85a5", "name": "Colocación de malla electrosoldada", "status": "pending", "category": "floor", "laborCost": 0, "description": "Instalación de malla de refuerzo", "estimatedHours": 2, "suggestedRoleType": "Albañil"}, {"id": "20bea982-b37d-4f9e-befb-b9030e55140d", "name": "Preparación y colado de cama de arena-cemento", "status": "pending", "category": "floor", "laborCost": 0, "description": "Preparación de 1.25m³ de mezcla y colado", "estimatedHours": 7, "suggestedRoleType": "Albañil"}], "other": [], "tiles": [{"id": "78e84156-5103-498f-95cc-b91bc4bc4ebd", "name": "Colocación de piscina de fibra", "status": "pending", "category": "tiles", "laborCost": 0, "description": "Posicionamiento y nivelación de piscina RECTANGULAR", "estimatedHours": 8, "suggestedRoleType": "Capataz"}, {"id": "65ebce41-bf15-4936-8ca4-46244f99a3f0", "name": "Colocación de losetas perimetrales", "status": "pending", "category": "tiles", "laborCost": 0, "description": "Colocación de losetas en 15.00m de perímetro", "estimatedHours": 12, "suggestedRoleType": "Colocador"}, {"id": "ed37d6b8-e57f-4851-874f-9c661e366453", "name": "Construcción de playa húmeda", "status": "pending", "category": "tiles", "laborCost": 0, "description": "Preparación y terminación de área de playa húmeda", "estimatedHours": 12, "suggestedRoleType": "Albañil"}], "finishes": [{"id": "43e66977-1c72-4dce-9adf-c7fb27334a5f", "name": "Pastinado de juntas", "status": "pending", "category": "finishes", "laborCost": 0, "description": "Terminación de juntas entre losetas", "estimatedHours": 5, "suggestedRoleType": "Colocador"}, {"id": "0ff297ce-e6bf-4d76-a9c4-d59908697402", "name": "Limpieza final de obra", "status": "pending", "category": "finishes", "laborCost": 0, "description": "Limpieza general del área de trabajo", "estimatedHours": 4, "suggestedRoleType": "Ayudante"}, {"id": "7cb4ecb1-3f15-4584-8b7c-2be5c55fe395", "name": "Llenado inicial y balanceo químico", "status": "pending", "category": "finishes", "laborCost": 0, "description": "Primer llenado y ajuste de pH y cloro", "estimatedHours": 2, "suggestedRoleType": "Especialista"}], "hydraulic": [{"id": "6c9f126c-fa76-455d-b104-37501bdc1295", "name": "Instalación de 1 skimmer(s)", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Colocación y conexión de skimmers", "estimatedHours": 2, "suggestedRoleType": "Plomero"}, {"id": "734e83ab-8501-4ccf-9adf-3c6bf6c3a793", "name": "Instalación de desagüe de fondo", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Colocación y conexión del desagüe principal", "estimatedHours": 3, "suggestedRoleType": "Plomero"}, {"id": "d138983d-9edf-4ad9-bc4c-60e65ee3457d", "name": "Instalación de 1 toma(s) de barrefondo", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Colocación de tomas para barrefondo", "estimatedHours": 1.5, "suggestedRoleType": "Plomero"}, {"id": "deb93857-5256-40f9-816a-7a4569489fb2", "name": "Instalación de 4 retorno(s)", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Instalación de retornos de agua", "estimatedHours": 6, "suggestedRoleType": "Plomero"}, {"id": "ad150f7e-b8d3-40fc-a2b7-41f7ca357b64", "name": "Tendido de cañerías principales", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Instalación de cañerías de impulsión y succión", "estimatedHours": 8, "suggestedRoleType": "Plomero"}, {"id": "17308048-353f-4899-8e01-f08a04dbe49a", "name": "Prueba hidráulica y detección de fugas", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Prueba de presión de todo el sistema hidráulico", "estimatedHours": 2, "suggestedRoleType": "Plomero"}], "electrical": [{"id": "bdddf37a-7af5-4bd4-a3aa-3ac3a2a099f2", "name": "Instalación de 2 luz(ces)", "status": "pending", "category": "electrical", "laborCost": 0, "description": "Instalación eléctrica de iluminación LED", "estimatedHours": 6, "suggestedRoleType": "Electricista"}, {"id": "908edd4d-3391-4381-9567-99090702aa65", "name": "Tendido de cableado eléctrico", "status": "pending", "category": "electrical", "laborCost": 0, "description": "Instalación de cableado para bombas y equipamiento", "estimatedHours": 6, "suggestedRoleType": "Electricista"}, {"id": "0f7358ae-5b1e-40e7-a876-eec4cc28403c", "name": "Conexión de tablero eléctrico", "status": "pending", "category": "electrical", "laborCost": 0, "description": "Instalación y configuración del tablero de comando", "estimatedHours": 4, "suggestedRoleType": "Electricista"}, {"id": "18304821-74c2-47a2-a793-1002f836ffba", "name": "Prueba eléctrica y puesta en marcha", "status": "pending", "category": "electrical", "laborCost": 0, "description": "Verificación de todo el sistema eléctrico", "estimatedHours": 2, "suggestedRoleType": "Electricista"}], "excavation": [{"id": "f4ba7cdf-4f3e-43a8-b050-96a1506ce16d", "name": "Replanteo y marcación del terreno", "status": "pending", "category": "excavation", "laborCost": 0, "description": "Marcación de 5m x 2.5m con colchones laterales", "estimatedHours": 2, "suggestedRoleType": "Capataz"}, {"id": "7a7f2d72-c7fa-43b8-ad4d-e6095f8a4525", "name": "Excavación de terreno", "status": "pending", "category": "excavation", "laborCost": 0, "description": "Excavación de aproximadamente 24.38m³ (incluye colchones)", "estimatedHours": 20, "suggestedRoleType": "Excavador"}, {"id": "fbb0ba15-0545-4e06-86f0-1305547076ee", "name": "Nivelación y compactación del fondo", "status": "pending", "category": "excavation", "laborCost": 0, "description": "Preparación del terreno para colocación de piscina", "estimatedHours": 4, "suggestedRoleType": "Excavador"}]}	{"east": {"rows": 2, "firstRingType": "", "selectedTileId": ""}, "west": {"rows": 4, "firstRingType": "", "selectedTileId": ""}, "north": {"rows": 2, "firstRingType": "", "selectedTileId": ""}, "south": {"rows": 2, "firstRingType": "", "selectedTileId": ""}}	4285750	{}	{}
83fec826-4269-4f72-b4c1-2ceb6d2f8b33	Familia Lopez	Eugenio Lopez	\N	\N	60dcc637-bcad-4715-bf1f-7fdaa4a476d3	15	12.5	16.25	0	0	{"sand": {"cost": 0, "unit": "m³", "quantity": "0.00"}, "tiles": [], "cement": {"cost": 0, "unit": "kg", "quantity": 0}, "gravel": {"cost": 0, "unit": "m³", "quantity": "0.00"}, "adhesive": {"cost": 0, "unit": "kg", "quantity": 0}, "cementKg": {"cost": 87500, "unit": "kg", "quantity": 313}, "wireMesh": {"cost": 0, "unit": "m²", "quantity": 0}, "marmolina": {"cost": 8500, "unit": "kg", "quantity": 9}, "cementBags": {"cost": 87500, "unit": "bolsas de 50kg", "quantity": 7}, "drainStone": {"cost": 0, "unit": "m³", "quantity": "0.00"}, "sandForBed": {"cost": 56250, "unit": "m³", "quantity": "1.25"}, "geomembrane": {"cost": 0, "unit": "m²", "quantity": 13}, "whiteCement": {"cost": 18500, "unit": "kg", "quantity": 13}, "waterproofing": {"cost": 0, "unit": "kg", "quantity": 0}, "electroweldedMesh": {"cost": 0, "unit": "m²", "quantity": 15}}	DRAFT	2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	2025-10-26 20:35:17.575	2025-10-26 20:35:38.801	1.4	5.3	2.8	0	\N	170750	{"floor": [{"id": "692712e0-848f-441e-8539-4fa9c9ea608c", "name": "Colocación de geomembrana", "status": "pending", "category": "floor", "laborCost": 0, "description": "Instalación de geomembrana en 12.50m²", "estimatedHours": 3, "suggestedRoleType": "Albañil"}, {"id": "bf788490-f598-4102-ab43-fce94b18deef", "name": "Colocación de malla electrosoldada", "status": "pending", "category": "floor", "laborCost": 0, "description": "Instalación de malla de refuerzo", "estimatedHours": 2, "suggestedRoleType": "Albañil"}, {"id": "c39b1ce4-4544-449c-bc92-7947108f22c8", "name": "Preparación y colado de cama de arena-cemento", "status": "pending", "category": "floor", "laborCost": 0, "description": "Preparación de 1.25m³ de mezcla y colado", "estimatedHours": 7, "suggestedRoleType": "Albañil"}], "other": [], "tiles": [{"id": "3debde29-89a0-42cf-a0ec-f60fc135c367", "name": "Colocación de piscina de fibra", "status": "pending", "category": "tiles", "laborCost": 0, "description": "Posicionamiento y nivelación de piscina RECTANGULAR", "estimatedHours": 8, "suggestedRoleType": "Capataz"}, {"id": "7fa218e4-8974-4a81-b996-6ffea26654ed", "name": "Colocación de losetas perimetrales", "status": "pending", "category": "tiles", "laborCost": 0, "description": "Colocación de losetas en 15.00m de perímetro", "estimatedHours": 12, "suggestedRoleType": "Colocador"}, {"id": "1a0c9970-ce18-4c55-a267-9e2a32d6255f", "name": "Construcción de playa húmeda", "status": "pending", "category": "tiles", "laborCost": 0, "description": "Preparación y terminación de área de playa húmeda", "estimatedHours": 12, "suggestedRoleType": "Albañil"}], "finishes": [{"id": "36156600-2724-4698-a855-a444c3254c6c", "name": "Pastinado de juntas", "status": "pending", "category": "finishes", "laborCost": 0, "description": "Terminación de juntas entre losetas", "estimatedHours": 5, "suggestedRoleType": "Colocador"}, {"id": "a9bdb13e-4a43-4dae-8736-7e7906f13556", "name": "Limpieza final de obra", "status": "pending", "category": "finishes", "laborCost": 0, "description": "Limpieza general del área de trabajo", "estimatedHours": 4, "suggestedRoleType": "Ayudante"}, {"id": "e98dd1fa-774b-4f8a-83ae-37d12d3c2fa6", "name": "Llenado inicial y balanceo químico", "status": "pending", "category": "finishes", "laborCost": 0, "description": "Primer llenado y ajuste de pH y cloro", "estimatedHours": 2, "suggestedRoleType": "Especialista"}], "hydraulic": [{"id": "5a2bf028-0781-4d82-8531-338722836d33", "name": "Instalación de 1 skimmer(s)", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Colocación y conexión de skimmers", "estimatedHours": 2, "suggestedRoleType": "Plomero"}, {"id": "36b93979-3e0c-4c7d-92d9-6b1c8e4047ea", "name": "Instalación de desagüe de fondo", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Colocación y conexión del desagüe principal", "estimatedHours": 3, "suggestedRoleType": "Plomero"}, {"id": "fb2ade2e-920a-4140-89b9-31a14e45f54c", "name": "Instalación de 1 toma(s) de barrefondo", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Colocación de tomas para barrefondo", "estimatedHours": 1.5, "suggestedRoleType": "Plomero"}, {"id": "b7860e08-a312-44c7-a448-66ab0e89f812", "name": "Instalación de 4 retorno(s)", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Instalación de retornos de agua", "estimatedHours": 6, "suggestedRoleType": "Plomero"}, {"id": "c43989e5-375a-4939-bcd0-e2c2a79f0dad", "name": "Tendido de cañerías principales", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Instalación de cañerías de impulsión y succión", "estimatedHours": 8, "suggestedRoleType": "Plomero"}, {"id": "6c91faf6-a537-4ded-b2ad-2dc3822ac4cd", "name": "Prueba hidráulica y detección de fugas", "status": "pending", "category": "hydraulic", "laborCost": 0, "description": "Prueba de presión de todo el sistema hidráulico", "estimatedHours": 2, "suggestedRoleType": "Plomero"}], "electrical": [{"id": "04ee7a38-a8f3-4c20-8b45-c65ae988066b", "name": "Instalación de 2 luz(ces)", "status": "pending", "category": "electrical", "laborCost": 0, "description": "Instalación eléctrica de iluminación LED", "estimatedHours": 6, "suggestedRoleType": "Electricista"}, {"id": "a5048542-388f-4578-bf4a-8f03a82f2535", "name": "Tendido de cableado eléctrico", "status": "pending", "category": "electrical", "laborCost": 0, "description": "Instalación de cableado para bombas y equipamiento", "estimatedHours": 6, "suggestedRoleType": "Electricista"}, {"id": "2f18ff87-6eee-4560-9f1b-0bed0a591d8a", "name": "Conexión de tablero eléctrico", "status": "pending", "category": "electrical", "laborCost": 0, "description": "Instalación y configuración del tablero de comando", "estimatedHours": 4, "suggestedRoleType": "Electricista"}, {"id": "390a6ef6-c45d-43ef-87c0-8f58a5117255", "name": "Prueba eléctrica y puesta en marcha", "status": "pending", "category": "electrical", "laborCost": 0, "description": "Verificación de todo el sistema eléctrico", "estimatedHours": 2, "suggestedRoleType": "Electricista"}], "excavation": [{"id": "268dfaa5-457f-46a9-958b-35c6325d0485", "name": "Replanteo y marcación del terreno", "status": "pending", "category": "excavation", "laborCost": 0, "description": "Marcación de 5m x 2.5m con colchones laterales", "estimatedHours": 2, "suggestedRoleType": "Capataz"}, {"id": "6328be69-51f2-48db-9480-2f74e9ce5b77", "name": "Excavación de terreno", "status": "pending", "category": "excavation", "laborCost": 0, "description": "Excavación de aproximadamente 24.38m³ (incluye colchones)", "estimatedHours": 20, "suggestedRoleType": "Excavador"}, {"id": "ec8ce222-74ea-426b-a813-82fa83a4c7ca", "name": "Nivelación y compactación del fondo", "status": "pending", "category": "excavation", "laborCost": 0, "description": "Preparación del terreno para colocación de piscina", "estimatedHours": 4, "suggestedRoleType": "Excavador"}]}	{"east": {"rows": 4, "firstRingType": "", "selectedTileId": ""}, "west": {"rows": 2, "firstRingType": "", "selectedTileId": ""}, "north": {"rows": 2, "firstRingType": "", "selectedTileId": ""}, "south": {"rows": 2, "firstRingType": "", "selectedTileId": ""}}	170750	{}	{}
\.


--
-- Data for Name: ProjectAdditional; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProjectAdditional" (id, "projectId", "accessoryId", "materialId", "equipmentId", "baseQuantity", "newQuantity", dependencies, notes, "createdAt", "updatedAt", "customCategory", "customLaborCost", "customName", "customPricePerUnit", "customUnit", "generatedTaskId", "relatedTaskCategory", "requiredRoleId") FROM stdin;
\.


--
-- Data for Name: ProjectShare; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProjectShare" (id, "projectId", "shareToken", "isActive", "showCosts", "showDetails", "expiresAt", "createdAt", "updatedAt", "clientPassword", "clientUsername") FROM stdin;
\.


--
-- Data for Name: ProjectUpdate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProjectUpdate" (id, "projectId", title, description, category, images, metadata, "createdAt", "updatedAt", "isPublic") FROM stdin;
\.


--
-- Data for Name: TilePreset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TilePreset" (id, name, width, length, brand, "createdAt", "updatedAt", description, "pricePerUnit", type, "cornerPricePerUnit", "cornersPerTile", "hasCorner", "isForFirstRing") FROM stdin;
8e438894-d413-4489-8d8e-c57e9afbcb02	Loseta Antideslizante 30x30cm Gris	0.3	0.3	Cerro Negro	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Loseta antideslizante para vereda exterior	1850	COMMON	\N	\N	f	f
3ccb16c0-5eae-40d8-acd4-e1efa0e3c2d0	Loseta Antideslizante 40x40cm Gris	0.4	0.4	Cerro Negro	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Loseta antideslizante para vereda exterior	2600	COMMON	\N	\N	f	f
bee1f8c5-ba0c-48bb-a2aa-5ca7bf41c0fb	Loseta Símil Madera 20x120cm	0.2	1.2	Ilva	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Porcelanato símil madera para deck	4200	COMMON	\N	\N	f	f
a8c66a49-1dd8-47a7-a182-d83fd8f0300e	Loseta Piedra Natural 40x40cm	0.4	0.4	San Lorenzo	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Loseta símil piedra natural antideslizante	3800	COMMON	\N	\N	f	f
af5a7ad2-3f90-4699-b3b9-976ef02fac68	Remate Lomo Ballena 12x25cm Blanco	0.12	0.25	Genérico	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Remate tipo lomo ballena para bordes	2200	LOMO_BALLENA	\N	\N	f	f
0fa5c1ed-fa57-4264-af39-54dc76ef68c9	Remate Lomo Ballena 12x25cm Azul	0.12	0.25	Genérico	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Remate tipo lomo ballena color azul	2400	LOMO_BALLENA	\N	\N	f	f
6560e5dd-e808-4354-bac7-93c2be072594	Terminación L 10x30cm	0.1	0.3	\N	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Terminación en L para bordes	1600	L_FINISH	\N	\N	f	f
1ddda613-0280-47fb-9606-01d306b94c56	Venecita Azul Piscina 2x2cm	0.02	0.02	Venecitas Córdoba	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Venecitas azul para revestimiento interior (precio por m²)	8500	PERIMETER	\N	\N	f	f
89426588-5774-4363-a07c-6a502d78923b	Venecita Verde Agua 2x2cm	0.02	0.02	Venecitas Córdoba	2025-10-26 20:51:44.572	2025-10-26 20:51:44.572	Venecitas verde agua para revestimiento (precio por m²)	9200	PERIMETER	\N	\N	f	f
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, password, name, role, "createdAt", "updatedAt", "googleId", provider) FROM stdin;
89c311cc-2600-43d2-a0de-bbf489fcb986	admin@aquam.com	$2a$10$fiSh9sAON6DERYpvvNfFQeYDDZnt99XxLOvgZbYsWh67LWcUPmg9W	Administrador	SUPERADMIN	2025-10-26 15:08:17.015	2025-10-26 15:08:17.015	\N	\N
e84513b2-620b-46cb-86c6-cadd1f4bc5b9	jesus@aquam.com	$2a$10$gA13Xa1duaHstzScGS4Eqe4WC5o2DcZKkuEz4pLf3p5Zin3Df0Xcu	Jesús Olguin	ADMIN	2025-10-26 15:08:30.596	2025-10-26 15:08:30.596	\N	\N
2eb2e60e-28e2-4f96-9de0-6b6ea50b6cbf	jesusnatec@gmail.com	$2a$10$Miqsl2B0vHMLBzl2715h2elTNE7yGAYs/aD3DSYDufggfcYqRx9m.	Jesús Olguin	SUPERADMIN	2025-10-26 15:11:08.244	2025-10-26 15:11:08.244	\N	\N
49ffe98c-d5a0-45f6-9eba-0027c2398ad7	chucky9425@gmail.com	$2a$10$rqb.NVAlXBuStAaDRqKgEecXdSwh35f5cL0oQdyh4T0.dZgJbdI/u	Cocacolero	ADMIN	2025-10-04 14:13:05.533	2025-10-04 14:13:05.533	\N	\N
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
f6614006-4dc3-4762-b55c-a96d51631db5	491cd9361ee0050f9565017803834f8efcbc57ba99b8120df6a9a3413e8577ca	2025-10-26 12:06:38.172153-03	20251002235134_init	\N	\N	2025-10-26 12:06:38.154098-03	1
a8ba52a9-3009-47e9-a04d-aae795cfd512	d291983377f9859bf052c21edf244be329ae9d40aefc4e081108ed64a5fc9280	2025-10-26 12:06:38.309514-03	20251017230614_add_superadmin_role	\N	\N	2025-10-26 12:06:38.303838-03	1
30349c1a-9de7-415a-a2db-eabe4e5c6cf2	92fb3a466089740b3caf2d4fc4b45a485a5d504d67dcbcdd13f8b5ebb61957c3	2025-10-26 12:06:38.183665-03	20251003002023_add_complete_presets	\N	\N	2025-10-26 12:06:38.174379-03	1
6d623a83-7e18-41cc-af8b-45844cf508df	f25265f8c81b0df1922fd3402a3c2599c23ea98f6b65ed0292f9adb370deae60	2025-10-26 12:06:38.191323-03	20251003010035_make_tileconfig_optional	\N	\N	2025-10-26 12:06:38.185479-03	1
05ba7e1c-69f1-478a-a379-8df29c72dccb	4c59e752a4c927dfe0e9e8696f6d04bd6b3541c86f8f2b18ac6452953bbcde34	2025-10-26 12:06:38.202777-03	20251003121532_add_pool_features_complete	\N	\N	2025-10-26 12:06:38.194611-03	1
33f3aa63-e13b-4419-9806-d4e2b8077809	997f8e8debb6fd9fe1291f946d681b4ec4c81d1d9945c0a3ad566078f72ee6ce	2025-10-26 12:06:38.3248-03	20251019155124_add_project_share	\N	\N	2025-10-26 12:06:38.312186-03	1
81d8a48c-d8aa-40d2-83b7-ecc4dbd291c9	6366976e085676948e70dfd2722f4e09261768b19f837bc3b37f2dbd81e36d1d	2025-10-26 12:06:38.213795-03	20251004133050_add_calculation_settings	\N	\N	2025-10-26 12:06:38.20548-03	1
52335d27-be8b-429c-97a1-61ec2a0b8634	82e7cb33460b0a36659aa7890787231a3b7f0d46438fc754903613831da977f4	2025-10-26 12:06:38.220063-03	20251004174606_update_sidewalk_base_thickness	\N	\N	2025-10-26 12:06:38.215611-03	1
73678d75-a4ea-4c9a-997c-8fdb485139e6	2b49d469830f90b1bfa0cda25dae3f4f7027f5ff62273f6325832f0db5e792bd	2025-10-26 12:06:38.232489-03	20251005013531_add_profession_roles	\N	\N	2025-10-26 12:06:38.221729-03	1
5428925b-5c17-41d5-a738-64a16f7150e7	3fc7c68f05664d8e1e61219f3c22ec559cd3a0de004c2345f190b1ca3a53393b	2025-10-26 12:06:38.336652-03	20251024170800_add_password_reset_and_oauth	\N	\N	2025-10-26 12:06:38.327556-03	1
ce3a38c9-590d-4d2c-8f26-b3630fde8236	c492ed13d596c175e34a99b3c60edf1b9f7bce3f9fc91224a9b0b27d84cccd7d	2025-10-26 12:06:38.244892-03	20251005022433_add_plumbing_items	\N	\N	2025-10-26 12:06:38.235154-03	1
d5697408-c462-48ef-bf4f-d847e7d5e7d4	491cd9361ee0050f9565017803834f8efcbc57ba99b8120df6a9a3413e8577ca	2025-10-04 10:44:32.446035-03	20251002235134_init	\N	\N	2025-10-04 10:44:32.405022-03	1
3616cdfb-4cdf-4008-a0de-39953fc1a7ab	95b189786f046368c68a0fb67c52e2cf9e9f96ed93427f157e28ca24b7b3591a	2025-10-26 12:06:38.252741-03	20251006014305_add_plumbing_config	\N	\N	2025-10-26 12:06:38.247445-03	1
7e4198b4-9b3e-4018-a93c-afcf6befc607	d291983377f9859bf052c21edf244be329ae9d40aefc4e081108ed64a5fc9280	2025-10-23 15:38:30.991866-03	20251017230614_add_superadmin_role	\N	\N	2025-10-23 15:38:30.987929-03	1
f3f591fd-1081-4b5c-b784-352f91952a72	f4b2c3519a4e3c1e42aa63dabd2ed92aa7068556af882c04f730d30730f2e949	2025-10-26 12:06:38.261998-03	20251006020943_add_bed_calculations_and_construction_type	\N	\N	2025-10-26 12:06:38.254454-03	1
e58f1839-dd1a-4545-bc28-b55b75210619	92fb3a466089740b3caf2d4fc4b45a485a5d504d67dcbcdd13f8b5ebb61957c3	2025-10-04 10:44:32.466808-03	20251003002023_add_complete_presets	\N	\N	2025-10-04 10:44:32.447278-03	1
b3d444ee-2432-48dd-8f55-357bd842b2e4	a7eac6de192ea70dc1100a78bc67e16e8a1ff345efce8e1c91bc59d0e002bd48	2025-10-26 12:06:38.285947-03	20251011045236_add_electrical_config	\N	\N	2025-10-26 12:06:38.264641-03	1
026392d0-a7b5-4303-a3b3-80c505128bb5	f25265f8c81b0df1922fd3402a3c2599c23ea98f6b65ed0292f9adb370deae60	2025-10-04 10:44:32.472533-03	20251003010035_make_tileconfig_optional	\N	\N	2025-10-04 10:44:32.467887-03	1
d305c006-e96d-4b8b-bfd0-9887b1ed155a	351e52e69be967c9455baea9ea07f4cd249867efc5a93976ff47f5e3602f26a2	2025-10-26 12:06:38.292578-03	20251011163458_add_custom_fields_to_project_additional	\N	\N	2025-10-26 12:06:38.288209-03	1
b9b42631-b215-4350-8faa-0ad2ce839b64	4c59e752a4c927dfe0e9e8696f6d04bd6b3541c86f8f2b18ac6452953bbcde34	2025-10-04 10:44:32.481513-03	20251003121532_add_pool_features_complete	\N	\N	2025-10-04 10:44:32.474292-03	1
23e416a4-7fba-40ec-ba55-d5e69e8d6c6b	5b36456792074c6ca3733195c979aec898c4bc0f62938bbe9a550c2de2473a3a	2025-10-26 12:06:38.301336-03	20251014141626_add_project_updates	\N	\N	2025-10-26 12:06:38.294656-03	1
ae1fa237-f2ab-412f-9f8b-368a86f1b9b2	997f8e8debb6fd9fe1291f946d681b4ec4c81d1d9945c0a3ad566078f72ee6ce	2025-10-23 15:38:31.009662-03	20251019155124_add_project_share	\N	\N	2025-10-23 15:38:30.994628-03	1
9e71ea3a-2f8f-4661-967f-b1d5e91d2e2c	6366976e085676948e70dfd2722f4e09261768b19f837bc3b37f2dbd81e36d1d	2025-10-04 10:44:32.497174-03	20251004133050_add_calculation_settings	\N	\N	2025-10-04 10:44:32.483565-03	1
321e4651-cd58-4005-b82f-9003cc9ae230	82e7cb33460b0a36659aa7890787231a3b7f0d46438fc754903613831da977f4	2025-10-04 14:46:06.961915-03	20251004174606_update_sidewalk_base_thickness	\N	\N	2025-10-04 14:46:06.951116-03	1
e60dbedc-fa41-45e3-8339-1ec9613195d4	2b49d469830f90b1bfa0cda25dae3f4f7027f5ff62273f6325832f0db5e792bd	2025-10-04 22:35:31.765906-03	20251005013531_add_profession_roles	\N	\N	2025-10-04 22:35:31.744777-03	1
173a1272-c328-4164-8382-431051595d95	c492ed13d596c175e34a99b3c60edf1b9f7bce3f9fc91224a9b0b27d84cccd7d	2025-10-04 23:24:33.300336-03	20251005022433_add_plumbing_items	\N	\N	2025-10-04 23:24:33.280475-03	1
c21913c7-5c9d-412b-9364-c2fd96e910b3	95b189786f046368c68a0fb67c52e2cf9e9f96ed93427f157e28ca24b7b3591a	2025-10-05 22:43:05.873925-03	20251006014305_add_plumbing_config	\N	\N	2025-10-05 22:43:05.862186-03	1
cf812d1e-e4f0-4648-97f1-0da0021a0c82	f4b2c3519a4e3c1e42aa63dabd2ed92aa7068556af882c04f730d30730f2e949	2025-10-05 23:09:43.025517-03	20251006020943_add_bed_calculations_and_construction_type	\N	\N	2025-10-05 23:09:43.010919-03	1
4fab5fb8-9dbe-4ad1-b454-7d74056ca763	a7eac6de192ea70dc1100a78bc67e16e8a1ff345efce8e1c91bc59d0e002bd48	2025-10-23 15:38:30.962719-03	20251011045236_add_electrical_config	\N	\N	2025-10-23 15:38:30.919901-03	1
1b9ceda9-c74f-4601-bb89-7f3bfc81bc45	351e52e69be967c9455baea9ea07f4cd249867efc5a93976ff47f5e3602f26a2	2025-10-23 15:38:30.968935-03	20251011163458_add_custom_fields_to_project_additional	\N	\N	2025-10-23 15:38:30.964329-03	1
cf153699-749b-42a9-bb0a-0eea8aece5cb	5b36456792074c6ca3733195c979aec898c4bc0f62938bbe9a550c2de2473a3a	2025-10-23 15:38:30.984855-03	20251014141626_add_project_updates	\N	\N	2025-10-23 15:38:30.970808-03	1
\.


--
-- Name: AccessoryPreset AccessoryPreset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AccessoryPreset"
    ADD CONSTRAINT "AccessoryPreset_pkey" PRIMARY KEY (id);


--
-- Name: BusinessRule BusinessRule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BusinessRule"
    ADD CONSTRAINT "BusinessRule_pkey" PRIMARY KEY (id);


--
-- Name: CalculationSettings CalculationSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalculationSettings"
    ADD CONSTRAINT "CalculationSettings_pkey" PRIMARY KEY (id);


--
-- Name: ConstructionMaterialPreset ConstructionMaterialPreset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConstructionMaterialPreset"
    ADD CONSTRAINT "ConstructionMaterialPreset_pkey" PRIMARY KEY (id);


--
-- Name: EquipmentPreset EquipmentPreset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EquipmentPreset"
    ADD CONSTRAINT "EquipmentPreset_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: PlumbingItem PlumbingItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PlumbingItem"
    ADD CONSTRAINT "PlumbingItem_pkey" PRIMARY KEY (id);


--
-- Name: PoolPreset PoolPreset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PoolPreset"
    ADD CONSTRAINT "PoolPreset_pkey" PRIMARY KEY (id);


--
-- Name: ProfessionRole ProfessionRole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProfessionRole"
    ADD CONSTRAINT "ProfessionRole_pkey" PRIMARY KEY (id);


--
-- Name: ProjectAdditional ProjectAdditional_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectAdditional"
    ADD CONSTRAINT "ProjectAdditional_pkey" PRIMARY KEY (id);


--
-- Name: ProjectShare ProjectShare_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectShare"
    ADD CONSTRAINT "ProjectShare_pkey" PRIMARY KEY (id);


--
-- Name: ProjectUpdate ProjectUpdate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectUpdate"
    ADD CONSTRAINT "ProjectUpdate_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: TilePreset TilePreset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TilePreset"
    ADD CONSTRAINT "TilePreset_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: BusinessRule_userId_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "BusinessRule_userId_category_idx" ON public."BusinessRule" USING btree ("userId", category);


--
-- Name: CalculationSettings_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CalculationSettings_userId_key" ON public."CalculationSettings" USING btree ("userId");


--
-- Name: EquipmentPreset_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "EquipmentPreset_name_key" ON public."EquipmentPreset" USING btree (name);


--
-- Name: PasswordResetToken_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordResetToken_token_idx" ON public."PasswordResetToken" USING btree (token);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: ProfessionRole_userId_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProfessionRole_userId_name_key" ON public."ProfessionRole" USING btree ("userId", name);


--
-- Name: ProjectAdditional_projectId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProjectAdditional_projectId_idx" ON public."ProjectAdditional" USING btree ("projectId");


--
-- Name: ProjectShare_clientUsername_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProjectShare_clientUsername_idx" ON public."ProjectShare" USING btree ("clientUsername");


--
-- Name: ProjectShare_clientUsername_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProjectShare_clientUsername_key" ON public."ProjectShare" USING btree ("clientUsername");


--
-- Name: ProjectShare_projectId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProjectShare_projectId_key" ON public."ProjectShare" USING btree ("projectId");


--
-- Name: ProjectShare_shareToken_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProjectShare_shareToken_idx" ON public."ProjectShare" USING btree ("shareToken");


--
-- Name: ProjectShare_shareToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProjectShare_shareToken_key" ON public."ProjectShare" USING btree ("shareToken");


--
-- Name: ProjectUpdate_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProjectUpdate_createdAt_idx" ON public."ProjectUpdate" USING btree ("createdAt");


--
-- Name: ProjectUpdate_projectId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProjectUpdate_projectId_idx" ON public."ProjectUpdate" USING btree ("projectId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_googleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_googleId_key" ON public."User" USING btree ("googleId");


--
-- Name: BusinessRule BusinessRule_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BusinessRule"
    ADD CONSTRAINT "BusinessRule_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CalculationSettings CalculationSettings_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CalculationSettings"
    ADD CONSTRAINT "CalculationSettings_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PoolPreset PoolPreset_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PoolPreset"
    ADD CONSTRAINT "PoolPreset_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProfessionRole ProfessionRole_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProfessionRole"
    ADD CONSTRAINT "ProfessionRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectAdditional ProjectAdditional_accessoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectAdditional"
    ADD CONSTRAINT "ProjectAdditional_accessoryId_fkey" FOREIGN KEY ("accessoryId") REFERENCES public."AccessoryPreset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProjectAdditional ProjectAdditional_equipmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectAdditional"
    ADD CONSTRAINT "ProjectAdditional_equipmentId_fkey" FOREIGN KEY ("equipmentId") REFERENCES public."EquipmentPreset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProjectAdditional ProjectAdditional_materialId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectAdditional"
    ADD CONSTRAINT "ProjectAdditional_materialId_fkey" FOREIGN KEY ("materialId") REFERENCES public."ConstructionMaterialPreset"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProjectAdditional ProjectAdditional_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectAdditional"
    ADD CONSTRAINT "ProjectAdditional_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProjectShare ProjectShare_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectShare"
    ADD CONSTRAINT "ProjectShare_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProjectUpdate ProjectUpdate_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectUpdate"
    ADD CONSTRAINT "ProjectUpdate_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Project Project_poolPresetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_poolPresetId_fkey" FOREIGN KEY ("poolPresetId") REFERENCES public."PoolPreset"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Project Project_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

